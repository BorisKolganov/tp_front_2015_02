define([
  'backbone',
  'router'
], function (Backbone, router) {
    Backbone.history.start();
});
