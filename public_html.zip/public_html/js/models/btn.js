define([
    'backbone'
], function(
    Backbone
){

    var Btn = Backbone.Model.extend({
    	initialize: function () {
    	}
    });

    return Btn;
});